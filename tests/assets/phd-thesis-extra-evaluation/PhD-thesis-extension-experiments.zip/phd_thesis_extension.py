import pandas as pd
from start_time_estimator.concurrency_oracle import HeuristicsConcurrencyOracle
from start_time_estimator.config import Configuration

from batch_processing_discovery.config import EventLogIDs
from batch_processing_discovery.discovery import discover_batches


def phd_thesis_extension():
    # Read input event log
    log_ids = EventLogIDs()
    dataset = "LoanApp_infRes_24-7_noTimers_batch"  # Mean WT: 0 days 00:17:18.225290106
    # dataset = "LoanApp_fewRes_9-5_timers_prior_batch"  # Mean WT: 2 days 07:40:56.379924836
    event_log = pd.read_csv(f"./assets/{dataset}.CSV")
    event_log[log_ids.start_time] = pd.to_datetime(event_log[log_ids.start_time], utc=True)
    event_log[log_ids.end_time] = pd.to_datetime(event_log[log_ids.end_time], utc=True)
    configuration = Configuration(
        log_ids=log_ids,
        consider_start_times=True,
    )
    oracle = HeuristicsConcurrencyOracle(event_log, configuration)
    oracle.add_enabled_times(event_log)
    # Identify batches
    batch_sizes = [2, 3, 4, 5, 6, 7, 8, 9, 10]
    time_gap_gap = pd.Timedelta(days=2, hours=7, minutes=40, seconds=56, milliseconds=380) / 4
    time_gaps = [pd.Timedelta(0), time_gap_gap, time_gap_gap * 2, time_gap_gap * 3, time_gap_gap * 4]
    for batch_size in batch_sizes:
        for time_gap_index, time_gap in enumerate(time_gaps):
            print(f"Reporting {batch_size} and {time_gap}\n")
            batched_event_log = discover_batches(
                event_log,
                log_ids,
                batch_min_size=batch_size,
                max_sequential_gap=time_gap
            )
            # Output log to file
            batched_event_log.to_csv(
                f"./assets/{dataset}__size_{batch_size}_timegap_{time_gap_index}.csv",
                index=False
            )
            # Output metrics
            with open(f"./assets/report__S02.csv", 'a', encoding='utf-8') as file:
                batch_true_positives, batch_false_positives = 0, 0
                for batch_id, events in batched_event_log.groupby('batch_instance_id'):
                    if sum(pd.isna(events['injected_batch_instance_id'])) > 0:
                        batch_false_positives += 1
                    else:
                        batch_true_positives += 1
                true_positives = sum(
                    (~pd.isna(batched_event_log['injected_batch_instance_id'])) &
                    (~pd.isna(batched_event_log['batch_instance_id']))
                )
                false_positives = sum(
                    (pd.isna(batched_event_log['injected_batch_instance_id'])) &
                    (~pd.isna(batched_event_log['batch_instance_id']))
                )
                file.write(
                    f"{dataset},{batch_size},{time_gap_index},{batch_true_positives},{batch_false_positives},{true_positives},{false_positives}\n")


if __name__ == '__main__':
    phd_thesis_extension()
